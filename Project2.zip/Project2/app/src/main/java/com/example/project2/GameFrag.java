package com.example.project2;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.shape.ShapeAppearanceModel;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link GameFrag#newInstance} factory method to
 * create an instance of this fragment.
 */
public class GameFrag extends Fragment implements View.OnClickListener, View.OnLongClickListener {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    //private String mParam1;
    //private String mParam2;

    public GameFrag() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment GameFrag.
     */
    // TODO: Rename and change types and number of parameters
    public static GameFrag newInstance(String param1, String param2) {
        GameFrag fragment = new GameFrag();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        */
    }

    //Variables to hold user input
    int numRows = 2;
    int numCols = 2;
    int percentMines = 50;
    int numMines;
    String hiddenColor = "Gray";
    String revealedColor = "Gray";
    String suspectedColor = "Gray";
    String mineColor = "Gray";

    //needed to set the face image
    ImageView face;

    //hold the 2d array representing the contents of the buttons mine, or number of mines around it
    int[][] contents;

    //holds the total number of cells the user has revealed
    int totalRevealed = 0;

    //Tells if the user has clicked on a mine or not, if they have not, they can still blow up
    boolean canBlowUp = true;

    //holds the inflated View, used to findViewById outside the onCreateView method
    View rootView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView =  inflater.inflate(R.layout.fragment_game, container, false);

        //load the data to the game fragment
        loadData();

        //build the mineSweeper grid
        //get a reference to the columns layout (a vertical linear layout)
        LinearLayout top = rootView.findViewById(R.id.top);
        placePicture(top);
        //create the layout that will hold the grid columns
        LinearLayout colsLayout = new LinearLayout(getContext());
        top.addView(colsLayout);
        buildGrid(colsLayout);

        //play the game, via the onClick Method

        return rootView;
    }

    private void placePicture(LinearLayout top){
        //get the face image and set it's properties
        face = new ImageView(getContext());
        //set the image to be displayed
        face.setImageResource(R.mipmap.neutral_foreground);
        //add the image to the layout
        top.addView(face);
    }

    //Place the buttons on the screen in a grid pattern
    private void buildGrid(LinearLayout colsLayout){
        //create the mine sweeper grid
        //Get the color that the hidden cell should be
        int color = getHiddenColor();

        //build the grid
        int id = 0;
        for(int i=0; i<numCols; i++){
            LinearLayout rowsLayout = new LinearLayout(getContext());
            rowsLayout.setOrientation(LinearLayout.VERTICAL);
            //build each row and add the number of buttons to it that's equal to the number of columns
            for(int j=0; j<numRows; j++){
                ImageButton button = new ImageButton(getContext());

                //set the color of the button
                //ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#FF6666"));
                ColorDrawable colorDrawable = new ColorDrawable(color);
                button.setImageDrawable(colorDrawable);

                //remove the border of the button
                //button.setBackgroundColor(Color.TRANSPARENT);

                //set the button tag with it's x and y pos in the grid
                button.setTag(i + "," + j);
                //set the id of the button
                button.setId(id);
                //set the onClickListener of the button
                //button.setOnClickListener(this);
                //set the onClickListener of the button
                button.setOnClickListener(this);
                //set the onLongClickListener of the button
                button.setOnLongClickListener(this);

                if(numRows == 5){
                    button.setMinimumHeight(200);
                }else if (numRows == 6 || numRows == 7){
                    button.setMinimumHeight(150);
                }else if(numRows == 8){
                    button.setMinimumHeight(125);
                }else if(numRows == 9 || numRows == 10){
                    button.setMinimumHeight(100);
                }
                if(numCols == 5){
                    button.setMinimumWidth(200);
                }else if (numCols == 6 || numCols == 7){
                    button.setMinimumWidth(150);
                }else if(numCols == 8){
                    button.setMinimumWidth(125);
                }else if(numCols == 9 || numCols == 10){
                    button.setMinimumWidth(100);
                }

                //add the button to the row
                rowsLayout.addView(button);
                id++;
            }
            //add the row to the layout
            colsLayout.addView(rowsLayout);
        }
        //build a 2D array to represent what is behind the buttons
        // (number of how many mines near, or a mine(-1))
        contents = buildArrayOfButtonContents();
    }//end of buildGrid

    //Populate a 2D array that will represent what the contents of each cell (or button) is
    private int[][] buildArrayOfButtonContents(){
        int[][] contents = new int[numRows][numCols];
        //Get the number of mines in the grid
        numMines = getNumberOfMines();

        //randomly populate the array with mines based on the number of mines
        Random random = new Random();
        Set<String> filledPos = new HashSet<>();

        for(int i=0; i < numMines; i++){
            int r, c;
            do{
                r = random.nextInt(numRows);
                c = random.nextInt(numCols);
            }while(filledPos.contains(r + "," + c)); //get random row and column while it's not filled

            contents[r][c] = -1;
            filledPos.add(r + "," + c);
        }

        //Fill the other positions with the number of mines around it
        for(int i=0; i<numRows; i++){
            for(int j=0; j<numCols; j++){
                if(contents[i][j] != -1){

                    //count the number of mines around the current position
                    int count = 0;
                    //count the pos to the left of the current one
                    if(j-1 >= 0 && contents[i][j-1] == -1){
                        count++;
                    }
                    //count the pos below the current one
                    if(i+1 < numRows && contents[i+1][j] == -1){
                        count++;
                    }
                    //count the pos to the right of the current one
                    if(j+1 < numCols && contents[i][j+1] == -1){
                        count++;
                    }
                    //count the pos above the current one
                    if(i-1 >= 0 && contents[i-1][j] == -1){
                        count++;
                    }
                    //count the pos down and right of the current pos
                    if(i+1 < numRows && j+1 < numCols && contents[i+1][j+1] == -1){
                        count++;
                    }
                    //count the pos down and left of the current pos
                    if(i+1 < numRows && j-1 >= 0 && contents[i+1][j-1] == -1){
                        count++;
                    }
                    //count the pos up and right of the current pos
                    if(i-1 >= 0 && j+1 < numCols && contents[i-1][j+1] == -1){
                        count++;
                    }
                    //count the pos up and left of the current pos
                    if(i-1 >= 0 && j-1 >= 0 && contents[i-1][j-1] == -1){
                        count++;
                    }
                    contents[i][j] = count;
                }
            }
        }
        return contents;
    }//end of buildArrayOfButtonContents()

    //Action to perform when the button (cell) is clicked
    @Override
    public void onClick(View v) {
        //Log.v("button id that was clicked: ", String.valueOf(v.getId()));

        //convert the generic view to an ImageButton
        ImageButton ib = (ImageButton)v;

        //get the color of the cell, to tell if it has been marked as suspected
        ColorDrawable currantColorDraw = (ColorDrawable) ib.getDrawable();
        int currantColor = currantColorDraw.getColor();

        //get the suspected color to compare to the currant color
        int suspectedCellColor = getSuspectedColor();

        //get the hidden color to make sure hidden and suspected are not equal
        //if they are equal it's assumed the cell is not suspected
        //i.e. if the user chose the same color for hidden and suspected, they can't suspect cells
        int hiddenCellColor = getHiddenColor();

        if(currantColor != suspectedCellColor || suspectedCellColor == hiddenCellColor){

            //get the contents of the cell
            String buttonTag = (String) ib.getTag();
            int content = getButtonContents(buttonTag);

            //reveal the cell
            revealCell(ib, content);
        }
    }//end of onClick

    //Action to perform when the button is held down
    @Override
    public boolean onLongClick(View v) {
        //Set the face to be scared
        face.setImageResource(R.mipmap.scared_foreground);

        //convert the generic view to an image button
        ImageButton ib = (ImageButton)v;
        //get the suspected Mine Color
        int suspectedCellColor = getSuspectedColor();
        int hiddenCellColor = getHiddenColor();

        if(suspectedCellColor != hiddenCellColor){
            //set the color of the button to be that of the suspected mine if it is not already suspected
            ColorDrawable currantColor = (ColorDrawable) ib.getDrawable();
            //if the current color is the hidden color set it to the suspected color
            //if the current color is the suspected color set it to the hidden color
            if(currantColor.getColor() == hiddenCellColor){
                ColorDrawable colorDrawable = new ColorDrawable(suspectedCellColor);
                ib.setImageDrawable(colorDrawable);
            } else if(currantColor.getColor() == suspectedCellColor){
                ColorDrawable colorDrawable = new ColorDrawable(hiddenCellColor);
                ib.setImageDrawable(colorDrawable);
            }
        }

        //wait 5 seconds then set back to neutral face
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if(canBlowUp){
                face.setImageResource(R.mipmap.neutral_foreground);
            }
        }, 5000);

        return true;
    }//end of onLongClick

    //This will reveal the cell or button that is passed in and show the content that was passed in
    private void revealCell(ImageButton ib, int content){
        //increase the totalNumber of revealed cells by 1
        totalRevealed++;
        //hold the color the cell is to be set to
        int color;

        //if the user has clicked on all non-mine cells then they win
        //checks if you can blow up, that means the user has not clicked on a mine
        if(content != -1 && totalRevealed == ((numRows * numCols) - numMines) && canBlowUp){
            //The user can no longer blow up because they won
            canBlowUp = false;
            //reveal all cells
            revealAllCells();
            //display you win toast
            displayToast("You Win!");
            //Display happy face
            face.setImageResource(R.mipmap.happy_foreground);
        }else if(content != -1){
            //if the cell is not a mine reveal it
            color = getRevealedColor();
            //reveal the clicked on tile
            //Get a textView that will hodl the number of mines around the revealed cell
            TextView txt = new TextView(getContext());
            //set the background color of the text View
            txt.setBackgroundColor(color);
            //set the text size
            txt.setTextSize(24);
            //set the height and width of the text to be the same as the button it will replace
            txt.setHeight(ib.getHeight());
            txt.setWidth(ib.getWidth());
            //center the text
            txt.setGravity(Gravity.CENTER);

            //set the value of the text view (How many mines are around the button)
            txt.setText(String.valueOf(content));

            //replace the button with the textView
            LinearLayout ll = (LinearLayout) ib.getParent();
            int index = ll.indexOfChild(ib);
            ll.removeView(ib);
            ll.addView(txt, index);

            //if a cell has no mines around it reveal all cells around it
            if(content == 0){
                //recursively calls the revealCell function depending on if it can reveal the surrounding cells
                revealCellsOnZero(ib);

            }
        } else{
            //This is if the user reveals a mine
            //set the color to the mine color
            color = getMineColor();
            //change the color of the button to that of a mine
            ColorDrawable colorDrawable = new ColorDrawable(color);
            ib.setImageDrawable(colorDrawable);

            //reveal all cells
            //I don't want to call the revealAllCells() method more than once
            //So, only call it if this is the first time a mine is revealed
            //(The user revealed the mine)
            //The user has lost if this is called.
            if(canBlowUp){
                //You can't blow up twice
                canBlowUp = false;
                //reveal all cells
                revealAllCells();

                //display you lose toast and end the game
                displayToast("You Lose!");
                //display dead face
                face.setImageResource(R.mipmap.dead_foreground);
            }

        }
    }

    //recursively calls the revealCell function depending on if it can reveal the surrounding cells
    //This is called if a cell with the contents of 0 is revealed
    private void revealCellsOnZero(ImageButton ib){
        int id = ib.getId();
        int nextButtonId;
        ImageButton nextButton;
        //id - 1 will be the cell above it
        //id + 1 will be the cell below it
        //id - numRows will be the cell to the left
        //id + numRows will be the cell to the right
        //id - 1 + numRows will be the cell up and to the right
        //id - 1 - numRows will be the cell up and to the left
        //id + 1 + numRows will be the cell down and to the right
        //id + 1 - numRows will be the cell down and to the left

        //reveal the cell above it
        if(checkValidId(ib, 0)){
            //get the id of the button above the current button
            //nextButtonId = getResources().getIdentifier(String.valueOf(id-1), "id", "com.example.project2");

            //reveal the cell if it has not already been revealed
            nextButton = rootView.findViewById(id-1);
            //nextButton = rootView.findViewById(nextButtonId);
            //if the cell has been found
            // (meaning it has not yet been revealed,
            // because when the cell is revealed the button is
            // removed and therefor the id no longer exists)
            if(nextButton != null){
                String nextButtonTag = (String) nextButton.getTag();
                int nextButtonContent = getButtonContents(nextButtonTag);
                revealCell(nextButton, nextButtonContent);
            }
        }

        //reveal the cell below it
        if(checkValidId(ib, 1)){
            //get the id of the button below the current button
            //nextButtonId = getResources().getIdentifier(String.valueOf(id+1), "id", "com.example.project2");

            //reveal the cell if it has not already been revealed
            nextButton = rootView.findViewById(id+1);
            //nextButton = rootView.findViewById(nextButtonId);
            //if the cell has been found
            // (meaning it has not yet been revealed,
            // because when the cell is revealed the button is
            // removed and therefor the id no longer exists)
            if(nextButton != null){
                String nextButtonTag = (String) nextButton.getTag();
                int nextButtonContent = getButtonContents(nextButtonTag);
                revealCell(nextButton, nextButtonContent);
            }
        }

        //reveal the cell to the left of it
        if(checkValidId(ib, 2)){
            //get the id of the button left of the current button
            //nextButtonId = getResources().getIdentifier(String.valueOf(id-numRows), "id", "com.example.project2");

            //reveal the cell if it has not already been revealed
            nextButton = rootView.findViewById(id-numRows);
            //nextButton = rootView.findViewById(nextButtonId);
            //if the cell has been found
            // (meaning it has not yet been revealed,
            // because when the cell is revealed the button is
            // removed and therefor the id no longer exists)
            if(nextButton != null){
                String nextButtonTag = (String) nextButton.getTag();
                int nextButtonContent = getButtonContents(nextButtonTag);
                revealCell(nextButton, nextButtonContent);
            }
        }

        //reveal the cell to the right of it
        if(checkValidId(ib, 3)){
            //get the id of the button right of the current button
            //nextButtonId = getResources().getIdentifier(String.valueOf(id+numRows), "id", "com.example.project2");

            //reveal the cell if it has not already been revealed
            nextButton = rootView.findViewById(id+numRows);
            //nextButton = rootView.findViewById(nextButtonId);
            //if the cell has been found
            // (meaning it has not yet been revealed,
            // because when the cell is revealed the button is
            // removed and therefor the id no longer exists)
            if(nextButton != null){
                String nextButtonTag = (String) nextButton.getTag();
                int nextButtonContent = getButtonContents(nextButtonTag);
                revealCell(nextButton, nextButtonContent);
            }
        }

        //reveal the cell up and to the right
        if(checkValidId(ib, 4)){
            //get the id of the button above and right of the current button
            //nextButtonId = getResources().getIdentifier(String.valueOf(id-1+numRows), "id", "com.example.project2");

            //reveal the cell if it has not already been revealed
            nextButton = rootView.findViewById(id-1+numRows);
            //nextButton = rootView.findViewById(nextButtonId);
            //if the cell has been found
            // (meaning it has not yet been revealed,
            // because when the cell is revealed the button is
            // removed and therefor the id no longer exists)
            if(nextButton != null){
                String nextButtonTag = (String) nextButton.getTag();
                int nextButtonContent = getButtonContents(nextButtonTag);
                revealCell(nextButton, nextButtonContent);
            }
        }

        //reveal the cell up and to the left
        if(checkValidId(ib, 5)){
            //get the id of the button above and left of the current button
            //nextButtonId = getResources().getIdentifier(String.valueOf(id-1-numRows), "id", "com.example.project2");

            //reveal the cell if it has not already been revealed
            nextButton = rootView.findViewById(id-1-numRows);
            //nextButton = rootView.findViewById(nextButtonId);
            //if the cell has been found
            // (meaning it has not yet been revealed,
            // because when the cell is revealed the button is
            // removed and therefor the id no longer exists)
            if(nextButton != null){
                String nextButtonTag = (String) nextButton.getTag();
                int nextButtonContent = getButtonContents(nextButtonTag);
                revealCell(nextButton, nextButtonContent);
            }
        }

        //reveal the cell down and to the right
        if(checkValidId(ib, 6)){
            //get the id of the button below and right of the current button
            //nextButtonId = getResources().getIdentifier(String.valueOf(id+1+numRows), "id", "com.example.project2");

            //reveal the cell if it has not already been revealed
            nextButton = rootView.findViewById(id+1+numRows);
            //nextButton = rootView.findViewById(nextButtonId);
            //if the cell has been found
            // (meaning it has not yet been revealed,
            // because when the cell is revealed the button is
            // removed and therefor the id no longer exists)
            if(nextButton != null){
                String nextButtonTag = (String) nextButton.getTag();
                int nextButtonContent = getButtonContents(nextButtonTag);
                revealCell(nextButton, nextButtonContent);
            }
        }

        //reveal the cell down and to the left
        if(checkValidId(ib, 7)){
            //get the id of the button below and left of the current button
            //nextButtonId = getResources().getIdentifier(String.valueOf(id+1-numRows), "id", "com.example.project2");

            //reveal the cell if it has not already been revealed
            nextButton = rootView.findViewById(id+1-numRows);
            //nextButton = rootView.findViewById(nextButtonId);
            //if the cell has been found
            // (meaning it has not yet been revealed,
            // because when the cell is revealed the button is
            // removed and therefor the id no longer exists)
            if(nextButton != null){
                String nextButtonTag = (String) nextButton.getTag();
                int nextButtonContent = getButtonContents(nextButtonTag);
                revealCell(nextButton, nextButtonContent);
            }
        }
    }//end of revealCellsOnZero(ImageButton ib)

    private void revealAllCells(){
        for(int i=0; i<(numRows*numCols); i++){

            ImageButton currentButton = rootView.findViewById(i);
            if(currentButton != null){
                String tag = (String) currentButton.getTag();
                int content = getButtonContents(tag);
                revealCell(currentButton, content);
            }
        }
    }//end of revealAllCells

    //return true if a cell has a cell to the
    // left, right, above, below, below right, below left, above right, or above left
    //depending on the position that is asked to be checked
    private boolean checkValidId(ImageButton ib, int pos){
        //pos 0 = up
        //pos 1 = down
        //pos 2 = left
        //pos 3 = right
        //pos 4 = up and right
        //pos 5 = up and left
        //pos 6 = down and right
        //pos 7 = down and left
        //else return -1

        boolean valid;

        String buttonTag = (String) ib.getTag();
        String[] stringPos = buttonTag.split(",");
        int x = Integer.parseInt(stringPos[0]);
        int y = Integer.parseInt(stringPos[1]);

        switch(pos){
            case 0:
                valid = y != 0;
                break;
            case 1:
                valid = y != numRows-1;
                break;
            case 2:
                valid = x != 0;
                break;
            case 3:
                valid = x != numCols-1;
                break;
            case 4:
                valid = y != 0 && x != numCols-1;
                break;
            case 5:
                valid = y != 0 && x != 0;
                break;
            case 6:
                valid = y != numRows-1 && x != numCols-1;
                break;
            case 7:
                valid = y != numRows-1 && x != 0;
                break;
            default:
                valid = false;
        }

        return valid;
    }//end of checkValdId

    //Get the contents of the cell (or button) that which the corresponding tag is passed in
    private int getButtonContents(String tag){
        //use the tag which contains the i, j pos of the buton to get it's contents from the
        // global variable int[][] contents, return the value.
        String[] stringCoords = tag.split(",");
        int[] coords = new int[2];
        coords[0] = Integer.parseInt(stringCoords[0]);
        coords[1] = Integer.parseInt(stringCoords[1]);

        return contents[coords[1]][coords[0]];
    }//end of get button contents

    //return the number of mines in the grid
    private int getNumberOfMines(){
        int totalSize = numRows * numCols;
        float percentInDec = (float)percentMines/100;

        return (int)(totalSize * percentInDec);

    }//end of getNumberOfMines

    //return the hidden color as an int
    private int getHiddenColor(){
        switch(hiddenColor){
            case "Red":
                return Color.RED;
            case "Blue":
                return Color.BLUE;
            case "Green":
                return Color.GREEN;
            case "Black":
                return Color.BLACK;
            case "White":
                return Color.WHITE;
            default:
                return Color.GRAY;
        }
    }//end of getHiddenColor

    //return the revealed color as an int
    private int getRevealedColor(){
        switch(revealedColor){
            case "Red":
                return Color.RED;
            case "Blue":
                return Color.BLUE;
            case "Green":
                return Color.GREEN;
            case "Black":
                return Color.BLACK;
            case "White":
                return Color.WHITE;
            default:
                return Color.GRAY;
        }
    }//end of getRevealedColor

    //return the suspected color as an int
    private int getSuspectedColor(){
        switch(suspectedColor){
            case "Red":
                return Color.RED;
            case "Blue":
                return Color.BLUE;
            case "Green":
                return Color.GREEN;
            case "Black":
                return Color.BLACK;
            case "White":
                return Color.WHITE;
            default:
                return Color.GRAY;
        }
    }//end of getSuspectedColor

    //return the mine color as an int
    private int getMineColor(){
        switch(mineColor){
            case "Red":
                return Color.RED;
            case "Blue":
                return Color.BLUE;
            case "Green":
                return Color.GREEN;
            case "Black":
                return Color.BLACK;
            case "White":
                return Color.WHITE;
            default:
                return Color.GRAY;
        }
    }//end of getMineColor

    //load the data from storage
    private void loadData(){
        if(this.getActivity() != null){
            SharedPreferences sp = this.getActivity().getSharedPreferences("settings", Context.MODE_PRIVATE);
            numRows = sp.getInt("numRows", 2);
            numCols = sp.getInt("numCols", 2);
            percentMines = sp.getInt("percentMines", 50);
            hiddenColor = sp.getString("hiddenColor", "Gray");
            revealedColor = sp.getString("revealedColor", "Gray");
            suspectedColor = sp.getString("suspectedColor", "Gray");
            mineColor = sp.getString("mineColor", "Gray");
        }
    }//end of loadData()

    private void displayToast(String str){
        Toast toast = new Toast(getContext());
        toast.setGravity(Gravity.BOTTOM,0,0);
        toast.setDuration(Toast.LENGTH_LONG); //display the toast for a "long time"
        toast.setText(str);
        toast.show();
    }

}