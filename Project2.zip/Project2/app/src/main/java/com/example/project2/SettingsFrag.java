package com.example.project2;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.fragment.NavHostFragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Spinner;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link SettingsFrag#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SettingsFrag extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public SettingsFrag() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SettingsFrag.
     */
    // TODO: Rename and change types and number of parameters
    public static SettingsFrag newInstance(String param1, String param2) {
        SettingsFrag fragment = new SettingsFrag();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    //spinners to collect the user input
    Spinner rowSpinner;
    Spinner colSpinner;
    Spinner percentMinesSpinner;
    Spinner hiddenColorSpinner;
    Spinner revealedColorSpinner;
    Spinner suspectedColorSpinner;
    Spinner mineColorSpinner;

    int rowSpinnerPos;
    int colSpinnerPos;
    int percentMinesSpinnerPos;
    int hiddenColorSpinnerPos;
    int revealedColorSpinnerPos;
    int suspectedColorSpinnerPos;
    int mineColorSpinnerPos;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //Will need a reference to the root view to get views from it
        View rootView = inflater.inflate(R.layout.fragment_settings, container, false);

        //get a reference to the spinners that will hold the user input values
        rowSpinner = rootView.findViewById(R.id.rowSpinner);
        colSpinner = rootView.findViewById(R.id.colSpinner);
        percentMinesSpinner = rootView.findViewById(R.id.mineSpinner);
        hiddenColorSpinner = rootView.findViewById(R.id.hiddenSpinner);
        revealedColorSpinner = rootView.findViewById(R.id.revealedSpinner);
        suspectedColorSpinner = rootView.findViewById(R.id.suspectedSpinner);
        mineColorSpinner = rootView.findViewById(R.id.mineColorSpinner);

        //load the spinner positions
        loadSpinnerPos();

        //set the spinner positions
        rowSpinner.setSelection(rowSpinnerPos);
        colSpinner.setSelection(colSpinnerPos);
        percentMinesSpinner.setSelection(percentMinesSpinnerPos);
        hiddenColorSpinner.setSelection(hiddenColorSpinnerPos);
        revealedColorSpinner.setSelection(revealedColorSpinnerPos);
        suspectedColorSpinner.setSelection(suspectedColorSpinnerPos);
        mineColorSpinner.setSelection(mineColorSpinnerPos);

        return rootView;
    }

    //Variables to hold user input
    int numRows;
    int numCols;
    int percentMines;
    String hiddenColor;
    String revealedColor;
    String suspectedColor;
    String mineColor;

    @Override
    public void onStop() {
        super.onStop();

        //Get the value of each spinner and put it in it's corresponding variable
        //.getSelectedItemPosition() returns the selected index, not the item at that position
        numRows = Integer.parseInt(String.valueOf(rowSpinner.getSelectedItem()));
        numCols = Integer.parseInt(String.valueOf(colSpinner.getSelectedItem()));
        percentMines = Integer.parseInt(String.valueOf(percentMinesSpinner.getSelectedItem()));
        hiddenColor = String.valueOf(hiddenColorSpinner.getSelectedItem());
        revealedColor = String.valueOf(revealedColorSpinner.getSelectedItem());
        suspectedColor = String.valueOf(suspectedColorSpinner.getSelectedItem());
        mineColor = String.valueOf(mineColorSpinner.getSelectedItem());

        //get the postion of the spinners so it can be saved and reset when the app is loaded
        rowSpinnerPos = rowSpinner.getSelectedItemPosition();
        colSpinnerPos = colSpinner.getSelectedItemPosition();
        percentMinesSpinnerPos = percentMinesSpinner.getSelectedItemPosition();
        hiddenColorSpinnerPos = hiddenColorSpinner.getSelectedItemPosition();
        revealedColorSpinnerPos = revealedColorSpinner.getSelectedItemPosition();
        suspectedColorSpinnerPos = suspectedColorSpinner.getSelectedItemPosition();
        mineColorSpinnerPos = mineColorSpinner.getSelectedItemPosition();

        saveData();
    }

    private void saveData(){
        SharedPreferences sp = this.getActivity().getSharedPreferences("settings", Context.MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();
        //save the spinner values
        e.putInt("numRows", numRows);
        e.putInt("numCols", numCols);
        e.putInt("percentMines", percentMines);
        e.putString("hiddenColor", hiddenColor);
        e.putString("revealedColor", revealedColor);
        e.putString("suspectedColor", suspectedColor);
        e.putString("mineColor", mineColor);

        //save the spinner positions
        e.putInt("rowSpinnerPos", rowSpinnerPos);
        e.putInt("colSpinnerPos", colSpinnerPos);
        e.putInt("percentMinesSpinnerPos", percentMinesSpinnerPos);
        e.putInt("hiddenColorSpinnerPos", hiddenColorSpinnerPos);
        e.putInt("revealedColorSpinnerPos", revealedColorSpinnerPos);
        e.putInt("suspectedColorSpinnerPos", suspectedColorSpinnerPos);
        e.putInt("mineColorSpinnerPos", mineColorSpinnerPos);
        e.apply();
    }//end of saveData

    private void loadSpinnerPos(){
        SharedPreferences sp = this.getActivity().getSharedPreferences("settings", Context.MODE_PRIVATE);

        //load the spinner positions
        rowSpinnerPos = sp.getInt("rowSpinnerPos", 0);
        colSpinnerPos = sp.getInt("colSpinnerPos", 0);
        percentMinesSpinnerPos = sp.getInt("percentMinesSpinnerPos", 0);
        hiddenColorSpinnerPos = sp.getInt("hiddenColorSpinnerPos", 0);
        revealedColorSpinnerPos = sp.getInt("revealedColorSpinnerPos", 0);
        suspectedColorSpinnerPos =  sp.getInt("suspectedColorSpinnerPos", 0);
        mineColorSpinnerPos =  sp.getInt("mineColorSpinnerPos", 0);
    }

}